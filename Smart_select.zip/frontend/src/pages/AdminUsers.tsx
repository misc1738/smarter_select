import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminHeader } from "../components/AdminHeader";
import { Button } from "../components/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/Card";
import { Input } from "../components/Input";
import { Select } from "../components/Select";
import { Badge } from "../components/Badge";

type UserRole = "admin" | "reviewer" | "student";
type UserStatus = "active" | "inactive" | "pending";

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  lastActive: string;
  dateCreated: string;
}

// Helper function to format dates
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

// Mock data for users
const mockUsers: User[] = [
  {
    id: "user-001",
    name: "Admin User",
    email: "admin@example.com",
    role: "admin",
    status: "active",
    lastActive: "2025-03-01",
    dateCreated: "2024-11-15",
  },
  {
    id: "user-002",
    name: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    role: "reviewer",
    status: "active",
    lastActive: "2025-03-03",
    dateCreated: "2024-12-01",
  },
  {
    id: "user-003",
    name: "Michael Chen",
    email: "michael.chen@example.com",
    role: "reviewer",
    status: "active",
    lastActive: "2025-02-28",
    dateCreated: "2024-12-10",
  },
  {
    id: "user-004",
    name: "Emily Wilson",
    email: "emily.wilson@example.com",
    role: "student",
    status: "active",
    lastActive: "2025-03-02",
    dateCreated: "2025-01-15",
  },
  {
    id: "user-005",
    name: "James Davis",
    email: "james.davis@example.com",
    role: "student",
    status: "active",
    lastActive: "2025-03-01",
    dateCreated: "2025-01-18",
  },
  {
    id: "user-006",
    name: "Maria Rodriguez",
    email: "maria.rodriguez@example.com",
    role: "student",
    status: "pending",
    lastActive: "",
    dateCreated: "2025-03-01",
  },
  {
    id: "user-007",
    name: "David Kim",
    email: "david.kim@example.com",
    role: "reviewer",
    status: "inactive",
    lastActive: "2025-02-15",
    dateCreated: "2024-12-05",
  },
  {
    id: "user-008",
    name: "Sophia Patel",
    email: "sophia.patel@example.com",
    role: "student",
    status: "active",
    lastActive: "2025-03-03",
    dateCreated: "2025-01-25",
  },
  {
    id: "user-009",
    name: "Thomas Anderson",
    email: "thomas.anderson@example.com",
    role: "student",
    status: "active",
    lastActive: "2025-03-02",
    dateCreated: "2025-02-01",
  },
  {
    id: "user-010",
    name: "Olivia Martinez",
    email: "olivia.martinez@example.com",
    role: "student",
    status: "pending",
    lastActive: "",
    dateCreated: "2025-03-02",
  },
];

// Function to get role badge based on user role
const getRoleBadge = (role: UserRole) => {
  switch (role) {
    case "admin":
      return <Badge variant="default">Administrator</Badge>;
    case "reviewer":
      return <Badge variant="secondary">Reviewer</Badge>;
    case "student":
      return <Badge variant="outline">Student</Badge>;
    default:
      return <Badge variant="outline">Unknown</Badge>;
  }
};

// Function to get status badge based on user status
const getStatusBadge = (status: UserStatus) => {
  switch (status) {
    case "active":
      return <Badge variant="success">Active</Badge>;
    case "inactive":
      return <Badge variant="destructive">Inactive</Badge>;
    case "pending":
      return <Badge variant="warning">Pending</Badge>;
    default:
      return <Badge variant="outline">Unknown</Badge>;
  }
};

export default function AdminUsers() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  
  // Filter users based on search term and filters
  const filteredUsers = mockUsers.filter(user => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === "" || user.role === roleFilter;
    const matchesStatus = statusFilter === "" || user.status === statusFilter;
    
    return matchesSearch && matchesRole && matchesStatus;
  });
  
  // Handle user actions
  const handleEditUser = (userId: string) => {
    // In a real app, this would open a modal or navigate to an edit page
    alert(`Edit user ${userId}. This would open a user edit form in the real app.`);
  };
  
  const handleDeactivateUser = (userId: string) => {
    // In a real app, this would make an API call
    alert(`Deactivate user ${userId}. This would update the user status in the real app.`);
  };
  
  const handleActivateUser = (userId: string) => {
    // In a real app, this would make an API call
    alert(`Activate user ${userId}. This would update the user status in the real app.`);
  };
  
  const handleResetPassword = (userId: string) => {
    // In a real app, this would trigger a password reset email
    alert(`Reset password for user ${userId}. This would send a password reset email in the real app.`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <AdminHeader activeTab="users" />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
            <p className="text-gray-600 mt-1">Manage system users and their permissions</p>
          </div>
          <Button onClick={() => alert("This would open a user creation form in the real app.")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Add User
          </Button>
        </div>
        
        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Filter users by various criteria</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Input
                label="Search"
                placeholder="Search by name or email"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              
              <Select
                label="Role"
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                options={[
                  { value: "", label: "All Roles" },
                  { value: "admin", label: "Administrator" },
                  { value: "reviewer", label: "Reviewer" },
                  { value: "student", label: "Student" },
                ]}
              />
              
              <Select
                label="Status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                options={[
                  { value: "", label: "All Statuses" },
                  { value: "active", label: "Active" },
                  { value: "inactive", label: "Inactive" },
                  { value: "pending", label: "Pending" },
                ]}
              />
            </div>
          </CardContent>
        </Card>
        
        {/* Users Table */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Users</CardTitle>
              <p className="text-sm text-gray-500">{filteredUsers.length} users found</p>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="py-3 px-4 text-left font-medium text-gray-500">User</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Role</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Status</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Last Active</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Date Created</th>
                    <th className="py-3 px-4 text-right font-medium text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div className="font-medium text-gray-900">{user.name}</div>
                        <div className="text-gray-500 text-xs">{user.email}</div>
                      </td>
                      <td className="py-3 px-4">{getRoleBadge(user.role)}</td>
                      <td className="py-3 px-4">{getStatusBadge(user.status)}</td>
                      <td className="py-3 px-4 text-gray-500">
                        {user.lastActive ? formatDate(user.lastActive) : "Never"}
                      </td>
                      <td className="py-3 px-4 text-gray-500">{formatDate(user.dateCreated)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => handleEditUser(user.id)}
                          >
                            Edit
                          </Button>
                          
                          {user.status === "active" ? (
                            <Button 
                              size="sm" 
                              variant="destructive" 
                              onClick={() => handleDeactivateUser(user.id)}
                            >
                              Deactivate
                            </Button>
                          ) : (
                            <Button 
                              size="sm" 
                              variant="default" 
                              onClick={() => handleActivateUser(user.id)}
                            >
                              Activate
                            </Button>
                          )}
                          
                          <Button 
                            size="sm" 
                            variant="secondary"
                            onClick={() => handleResetPassword(user.id)}
                          >
                            Reset Password
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
