import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AdminHeader } from "../components/AdminHeader";
import { Button } from "../components/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "../components/Card";
import { Separator } from "../components/Separator";
import { Badge } from "../components/Badge";
import { Avatar } from "../components/Avatar";

// Define application status type
type ApplicationStatus = "submitted" | "under_review" | "approved" | "rejected" | "pending_documents";

// Define interface for document
interface Document {
  id: string;
  name: string;
  type: string;
  status: "verified" | "pending" | "rejected";
  uploadedAt: string;
  size: string;
}

// Define interface for Application
interface Application {
  id: string;
  studentName: string;
  email: string;
  scholarshipName: string;
  scholarshipId: string;
  status: ApplicationStatus;
  submittedAt: string;
  lastUpdated: string;
  gpa: number;
  major: string;
  academicYear: string;
  institution: string;
  personalStatement: string;
  documents: Document[];
  reviewNotes: string;
  eligibilityScore: number;
}

// Mock application data
const mockApplicationData: Record<string, Application> = {
  "app-001": {
    id: "app-001",
    studentName: "Michael Johnson",
    email: "michael.johnson@example.com",
    scholarshipName: "Future Leaders Scholarship",
    scholarshipId: "sch-001",
    status: "under_review",
    submittedAt: "2025-02-10",
    lastUpdated: "2025-02-15",
    gpa: 3.8,
    major: "Business Administration",
    academicYear: "Junior",
    institution: "University of California, Berkeley",
    personalStatement: "As a first-generation college student, my journey in pursuing higher education has been marked by both challenges and transformative experiences. Growing up in a working-class household, I witnessed my parents' unwavering dedication to providing opportunities they never had. Their resilience instilled in me a deep appreciation for education and a commitment to making the most of every opportunity.\n\nMy interest in business leadership began during high school when I started a small tutoring service that grew to help over 30 students in my community. This experience revealed the impact of combining entrepreneurial thinking with social purpose. At UC Berkeley, I've expanded my understanding of how business principles can be applied to drive positive change across various sectors.\n\nI've maintained a 3.8 GPA while actively participating in the Business Leadership Association, where I now serve as Vice President of Community Outreach. In this role, I've organized partnerships with local non-profits, providing them with pro-bono business consultations from our student members. Last semester, I led a team that helped a local food bank optimize their distribution logistics, resulting in a 25% increase in their operational efficiency.\n\nThis summer, I completed an internship with a social enterprise focused on sustainable supply chain management. This experience deepened my understanding of how business strategies can support both financial and social objectives. It also confirmed my career goal of developing inclusive business models that create opportunities for underrepresented communities.\n\nThe Future Leaders Scholarship would enable me to complete my education without the financial burden that might otherwise limit my ability to pursue purpose-driven work after graduation. Rather than having to prioritize immediate income, I would have the freedom to seek roles where I can make meaningful contributions to organizations aligned with my values of equity, sustainability, and innovation.\n\nLooking forward, I plan to leverage my business education to address social inequities through entrepreneurship and organizational leadership. My long-term vision is to establish a social business incubator focused on supporting first-generation entrepreneurs in underserved communities. With your investment in my education, I can build the knowledge, skills, and networks necessary to realize this vision and pay forward the opportunities I've been fortunate to receive.",
    documents: [
      {
        id: "doc-001",
        name: "Transcript",
        type: "PDF",
        status: "verified",
        uploadedAt: "2025-02-10",
        size: "1.2 MB"
      },
      {
        id: "doc-002",
        name: "Financial Information",
        type: "PDF",
        status: "verified",
        uploadedAt: "2025-02-10",
        size: "850 KB"
      },
      {
        id: "doc-003",
        name: "Recommendation Letter",
        type: "PDF",
        status: "verified",
        uploadedAt: "2025-02-09",
        size: "500 KB"
      },
      {
        id: "doc-004",
        name: "Resume",
        type: "PDF",
        status: "verified",
        uploadedAt: "2025-02-08",
        size: "725 KB"
      },
    ],
    reviewNotes: "Candidate shows excellent leadership potential and has demonstrated commitment to community service. Financial need is well documented. GPA meets our requirements.",
    eligibilityScore: 92
  },
  // Additional mock data for other applications would go here
};

// Function to get a status badge based on application status
const getStatusBadge = (status: ApplicationStatus) => {
  switch (status) {
    case "submitted":
      return <Badge variant="secondary">Submitted</Badge>;
    case "under_review":
      return <Badge variant="primary">Under Review</Badge>;
    case "approved":
      return <Badge variant="success">Approved</Badge>;
    case "rejected":
      return <Badge variant="destructive">Rejected</Badge>;
    case "pending_documents":
      return <Badge variant="warning">Pending Documents</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
};

// Function to get a document status badge
const getDocumentStatusBadge = (status: "verified" | "pending" | "rejected") => {
  switch (status) {
    case "verified":
      return <Badge variant="success">Verified</Badge>;
    case "pending":
      return <Badge variant="warning">Pending</Badge>;
    case "rejected":
      return <Badge variant="destructive">Rejected</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
};

// Helper function to format dates
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

export default function ApplicationDetail() {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Extract application ID from URL query parameters
  const params = new URLSearchParams(location.search);
  const applicationId = params.get('id');
  
  const [application, setApplication] = useState<Application | null>(null);
  const [loading, setLoading] = useState(true);
  const [reviewNotes, setReviewNotes] = useState("");
  
  useEffect(() => {
    // In a real app, this would fetch data from an API
    if (applicationId && mockApplicationData[applicationId]) {
      setApplication(mockApplicationData[applicationId]);
      setReviewNotes(mockApplicationData[applicationId].reviewNotes);
    }
    setLoading(false);
  }, [applicationId]);
  
  const handleApprove = () => {
    // In a real app, this would make an API call
    alert(`Approving application ${applicationId}. This would update the status in the real app.`);
  };
  
  const handleReject = () => {
    // In a real app, this would make an API call
    alert(`Rejecting application ${applicationId}. This would update the status in the real app.`);
  };
  
  const handleRequestDocuments = () => {
    // In a real app, this would make an API call and send an email
    alert(`Requesting additional documents from ${application?.studentName}. This would send an email in the real app.`);
  };
  
  const handleSaveNotes = () => {
    // In a real app, this would make an API call to save notes
    if (application) {
      alert(`Saving review notes for application ${applicationId}. This would update the notes in the real app.`);
    }
  };
  
  if (loading) {
    return (
      <div className="flex flex-col min-h-screen bg-gray-50">
        <AdminHeader activeTab="applications" />
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="text-gray-500">Loading application details...</div>
          </div>
        </main>
      </div>
    );
  }
  
  if (!application) {
    return (
      <div className="flex flex-col min-h-screen bg-gray-50">
        <AdminHeader activeTab="applications" />
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="flex flex-col items-center justify-center h-64">
            <div className="text-gray-800 text-lg font-medium mb-2">Application Not Found</div>
            <p className="text-gray-500 mb-4">The application you're looking for does not exist or has been removed.</p>
            <Button onClick={() => navigate("/AdminApplications")}>
              Return to Applications
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <AdminHeader activeTab="applications" />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center">
              <h1 className="text-3xl font-bold text-gray-900 mr-3">Application Review</h1>
              {getStatusBadge(application.status)}
            </div>
            <p className="text-gray-600 mt-1">Submitted on {formatDate(application.submittedAt)}</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={() => navigate("/AdminApplications")}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to Applications
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Student Information */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle>Student Information</CardTitle>
              <CardDescription>Applicant details and eligibility</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center mb-6">
                <Avatar 
                  className="h-16 w-16 mr-4" 
                  name={application.studentName}
                />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{application.studentName}</h3>
                  <p className="text-gray-500">{application.email}</p>
                </div>
              </div>
              
              <dl className="space-y-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Institution</dt>
                  <dd className="text-gray-900">{application.institution}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Academic Year</dt>
                  <dd className="text-gray-900">{application.academicYear}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Major</dt>
                  <dd className="text-gray-900">{application.major}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">GPA</dt>
                  <dd className="text-gray-900">{application.gpa}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Eligibility Score</dt>
                  <dd>
                    <div className="flex items-center mt-1">
                      <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
                        <div 
                          className={`h-2.5 rounded-full ${application.eligibilityScore >= 90 ? 'bg-green-600' : application.eligibilityScore >= 70 ? 'bg-blue-600' : 'bg-yellow-500'}`} 
                          style={{ width: `${application.eligibilityScore}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{application.eligibilityScore}%</span>
                    </div>
                  </dd>
                </div>
              </dl>
            </CardContent>
          </Card>
          
          {/* Scholarship Information */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Scholarship Details</CardTitle>
              <CardDescription>Information about the scholarship program</CardDescription>
            </CardHeader>
            <CardContent>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">{application.scholarshipName}</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-2">Key Requirements</h4>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-gray-700">Minimum GPA of 3.5</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-gray-700">Demonstrated leadership experience</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-gray-700">Community service involvement</span>
                    </li>
                    <li className="flex items-start">
                      <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-gray-700">Financial need documentation</span>
                    </li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-500 mb-2">Scholarship Information</h4>
                  <dl className="space-y-2">
                    <div className="flex">
                      <dt className="text-gray-500 w-32">Award Amount:</dt>
                      <dd className="text-gray-900 font-medium">$8,000</dd>
                    </div>
                    <div className="flex">
                      <dt className="text-gray-500 w-32">Deadline:</dt>
                      <dd className="text-gray-900">May 1, 2025</dd>
                    </div>
                    <div className="flex">
                      <dt className="text-gray-500 w-32">Type:</dt>
                      <dd className="text-gray-900">Merit-based</dd>
                    </div>
                    <div className="flex">
                      <dt className="text-gray-500 w-32">Total Awards:</dt>
                      <dd className="text-gray-900">25</dd>
                    </div>
                  </dl>
                </div>
              </div>
              
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => navigate(`/ScholarshipForm?id=${application.scholarshipId}`)}
                >
                  View Scholarship Details
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Documents Section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Submitted Documents</CardTitle>
            <CardDescription>Review and verify applicant documents</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Document</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Type</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Size</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Uploaded</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Status</th>
                    <th className="py-3 px-4 text-right font-medium text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {application.documents.map((document) => (
                    <tr key={document.id} className="hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium text-gray-900">{document.name}</td>
                      <td className="py-3 px-4 text-gray-700">{document.type}</td>
                      <td className="py-3 px-4 text-gray-700">{document.size}</td>
                      <td className="py-3 px-4 text-gray-700">{formatDate(document.uploadedAt)}</td>
                      <td className="py-3 px-4">{getDocumentStatusBadge(document.status)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => alert(`Viewing document ${document.id}. This would open the document in the real app.`)}
                          >
                            View
                          </Button>
                          <Button 
                            size="sm" 
                            variant="secondary"
                            onClick={() => alert(`Verifying document ${document.id}. This would update the status in the real app.`)}
                          >
                            Verify
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            {application.documents.length === 0 && (
              <div className="text-center py-6">
                <p className="text-gray-500">No documents have been submitted yet.</p>
              </div>
            )}
            
            <div className="mt-4">
              <Button 
                variant="outline"
                onClick={handleRequestDocuments}
              >
                Request Additional Documents
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Personal Statement */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Personal Statement</CardTitle>
            <CardDescription>Applicant's scholarship essay</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-6 rounded-md whitespace-pre-line text-gray-800">
              {application.personalStatement}
            </div>
          </CardContent>
        </Card>
        
        {/* Review Notes */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Review Notes</CardTitle>
            <CardDescription>Internal notes and decision rationale</CardDescription>
          </CardHeader>
          <CardContent>
            <textarea
              className="w-full h-32 p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Add your review notes here..."
              value={reviewNotes}
              onChange={(e) => setReviewNotes(e.target.value)}
            ></textarea>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button 
              variant="outline"
              onClick={handleSaveNotes}
            >
              Save Notes
            </Button>
          </CardFooter>
        </Card>
        
        {/* Decision Section */}
        <Card>
          <CardHeader>
            <CardTitle>Application Decision</CardTitle>
            <CardDescription>Make a final determination on this application</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row justify-between items-center gap-6 p-6 bg-gray-50 rounded-md">
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to make a decision?</h3>
                <p className="text-gray-600">This action will notify the applicant of your decision and update their status.</p>
              </div>
              <div className="flex space-x-3">
                <Button 
                  variant="outline"
                  className="border-red-300 text-red-700 hover:bg-red-50"
                  onClick={handleReject}
                >
                  Reject Application
                </Button>
                <Button 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={handleApprove}
                >
                  Approve Application
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
