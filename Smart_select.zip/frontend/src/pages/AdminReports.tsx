import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminHeader } from "../components/AdminHeader";
import { Button } from "../components/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/Card";
import { Select } from "../components/Select";
import { Separator } from "../components/Separator";

// In a real app, this would use a charting library like recharts or Chart.js
// For this mockup, we'll use simple HTML/CSS to represent charts

interface ReportType {
  id: string;
  name: string;
  description: string;
  category: "applicants" | "scholarships" | "financial" | "outcomes";
}

const reportTypes: ReportType[] = [
  {
    id: "report-001",
    name: "Application Volume Trends",
    description: "Track application volume over time with breakdowns by scholarship category",
    category: "applicants",
  },
  {
    id: "report-002",
    name: "Scholarship Distribution",
    description: "Analyze scholarship distribution by category, amount, and demographic factors",
    category: "scholarships",
  },
  {
    id: "report-003",
    name: "Applicant Demographics",
    description: "Understand the demographic breakdown of your applicant pool",
    category: "applicants",
  },
  {
    id: "report-004",
    name: "Award Utilization",
    description: "Track how effectively scholarship funds are being utilized",
    category: "financial",
  },
  {
    id: "report-005",
    name: "Academic Outcomes",
    description: "Measure the academic success of scholarship recipients",
    category: "outcomes",
  },
  {
    id: "report-006",
    name: "Application Completion Rates",
    description: "Analyze application start vs. completion rates and abandonment points",
    category: "applicants",
  },
  {
    id: "report-007",
    name: "Financial Impact Analysis",
    description: "Assess the financial impact of your scholarship programs",
    category: "financial",
  },
  {
    id: "report-008",
    name: "Reviewer Performance",
    description: "Evaluate reviewer throughput, consistency, and quality metrics",
    category: "applicants",
  },
];

export default function AdminReports() {
  const navigate = useNavigate();
  const [selectedReportId, setSelectedReportId] = useState("report-001");
  const [timeRange, setTimeRange] = useState("past-year");
  
  // Get the selected report
  const selectedReport = reportTypes.find(report => report.id === selectedReportId) || reportTypes[0];
  
  // Function to render the mock chart for the selected report
  const renderReportContent = () => {
    return (
      <div className="space-y-8">
        {/* Chart Title and Description */}
        <div>
          <h3 className="text-xl font-semibold text-gray-800">{selectedReport.name}</h3>
          <p className="text-gray-600">{selectedReport.description}</p>
        </div>
        
        {/* Chart Filters */}
        <div className="flex flex-wrap gap-4">
          <Select
            label="Time Range"
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value)}
            options={[
              { value: "past-month", label: "Past Month" },
              { value: "past-quarter", label: "Past Quarter" },
              { value: "past-year", label: "Past Year" },
              { value: "all-time", label: "All Time" },
            ]}
            className="w-40"
          />
          
          {selectedReport.category === "scholarships" && (
            <Select
              label="Scholarship Category"
              value="all"
              onChange={() => {}}
              options={[
                { value: "all", label: "All Categories" },
                { value: "leadership", label: "Leadership" },
                { value: "stem", label: "STEM" },
                { value: "arts", label: "Arts" },
                { value: "community-service", label: "Community Service" },
              ]}
              className="w-48"
            />
          )}
          
          {selectedReport.category === "applicants" && (
            <Select
              label="Breakdown By"
              value="academic-year"
              onChange={() => {}}
              options={[
                { value: "academic-year", label: "Academic Year" },
                { value: "major", label: "Major" },
                { value: "gender", label: "Gender" },
                { value: "ethnicity", label: "Ethnicity" },
                { value: "geographic", label: "Geographic Region" },
              ]}
              className="w-48"
            />
          )}
        </div>
        
        {/* Mock Chart */}
        <div className="p-4 bg-white border rounded-lg">
          {selectedReport.id === "report-001" && (
            <div className="h-64 w-full">
              <div className="text-center py-6">Application Volume Trends</div>
              <div className="h-36 px-4 flex items-end justify-around">
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '30%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '45%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '35%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '60%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '75%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '85%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '100%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '90%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '95%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '80%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '90%' }}></div>
                <div className="w-8 bg-blue-500 rounded-t" style={{ height: '100%' }}></div>
              </div>
              <div className="px-4 pt-2 flex justify-around text-xs text-gray-500">
                <div>Mar</div>
                <div>Apr</div>
                <div>May</div>
                <div>Jun</div>
                <div>Jul</div>
                <div>Aug</div>
                <div>Sep</div>
                <div>Oct</div>
                <div>Nov</div>
                <div>Dec</div>
                <div>Jan</div>
                <div>Feb</div>
              </div>
            </div>
          )}
          
          {selectedReport.id === "report-002" && (
            <div className="h-64 w-full">
              <div className="text-center py-6">Scholarship Distribution by Category</div>
              <div className="flex justify-center">
                <div className="h-48 w-48 rounded-full overflow-hidden flex flex-wrap">
                  <div className="h-24 w-24 bg-blue-500"></div>
                  <div className="h-24 w-24 bg-green-500"></div>
                  <div className="h-24 w-24 bg-yellow-500"></div>
                  <div className="h-24 w-24 bg-red-500"></div>
                </div>
              </div>
            </div>
          )}
          
          {selectedReport.id === "report-003" && (
            <div className="h-64 w-full">
              <div className="text-center py-6">Applicant Demographics</div>
              <div className="h-36 px-4 flex items-end justify-around">
                <div className="w-16 flex flex-col items-center">
                  <div className="w-full bg-indigo-500 rounded-t" style={{ height: '70px' }}></div>
                  <div className="mt-2 text-xs">Freshman</div>
                </div>
                <div className="w-16 flex flex-col items-center">
                  <div className="w-full bg-indigo-500 rounded-t" style={{ height: '90px' }}></div>
                  <div className="mt-2 text-xs">Sophomore</div>
                </div>
                <div className="w-16 flex flex-col items-center">
                  <div className="w-full bg-indigo-500 rounded-t" style={{ height: '120px' }}></div>
                  <div className="mt-2 text-xs">Junior</div>
                </div>
                <div className="w-16 flex flex-col items-center">
                  <div className="w-full bg-indigo-500 rounded-t" style={{ height: '100px' }}></div>
                  <div className="mt-2 text-xs">Senior</div>
                </div>
                <div className="w-16 flex flex-col items-center">
                  <div className="w-full bg-indigo-500 rounded-t" style={{ height: '50px' }}></div>
                  <div className="mt-2 text-xs">Graduate</div>
                </div>
              </div>
            </div>
          )}
          
          {(selectedReport.id !== "report-001" && selectedReport.id !== "report-002" && selectedReport.id !== "report-003") && (
            <div className="h-64 flex items-center justify-center">
              <div className="text-center text-gray-500">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                </svg>
                <p className="mt-2">Chart visualization would appear here</p>
              </div>
            </div>
          )}
        </div>
        
        {/* Chart Legend and Context */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Key Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                  <span>Overall application volume increased by 35% compared to the previous period</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                  <span>STEM scholarships saw the highest growth in applicants (48% increase)</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                  <span>Junior students represent the largest applicant segment (39% of total)</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-amber-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <span>Application completion rate declined slightly from 72% to 68%</span>
                </li>
              </ul>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Recommended Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-blue-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  <span>Investigate declining completion rates by adding an exit survey</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-blue-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  <span>Consider creating targeted scholarships for underrepresented groups</span>
                </li>
                <li className="flex items-start">
                  <svg className="h-5 w-5 text-blue-500 mr-2 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  <span>Enhance marketing efforts for scholarship awareness during peak application seasons</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
        
        {/* Export Options */}
        <div className="flex justify-end space-x-3">
          <Button variant="outline" onClick={() => alert("This would download a CSV file in the real app")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3M3 17V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
            </svg>
            Export CSV
          </Button>
          <Button variant="outline" onClick={() => alert("This would download a PDF report in the real app")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Generate PDF Report
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <AdminHeader activeTab="reports" />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Reports & Analytics</h1>
            <p className="text-gray-600 mt-1">Access insights and data-driven reports for your scholarship programs</p>
          </div>
          <Button variant="outline" onClick={() => navigate("/AdminDashboard")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            Dashboard
          </Button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Report Types Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Report Library</CardTitle>
                <CardDescription>Select a report to view</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">APPLICANT REPORTS</h3>
                    <ul className="space-y-1">
                      {reportTypes
                        .filter(report => report.category === "applicants")
                        .map(report => (
                          <li key={report.id}>
                            <button
                              onClick={() => setSelectedReportId(report.id)}
                              className={`w-full text-left px-3 py-2 rounded-md text-sm ${selectedReportId === report.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700 hover:bg-gray-100'}`}
                            >
                              {report.name}
                            </button>
                          </li>
                        ))}
                    </ul>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">SCHOLARSHIP REPORTS</h3>
                    <ul className="space-y-1">
                      {reportTypes
                        .filter(report => report.category === "scholarships")
                        .map(report => (
                          <li key={report.id}>
                            <button
                              onClick={() => setSelectedReportId(report.id)}
                              className={`w-full text-left px-3 py-2 rounded-md text-sm ${selectedReportId === report.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700 hover:bg-gray-100'}`}
                            >
                              {report.name}
                            </button>
                          </li>
                        ))}
                    </ul>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">FINANCIAL REPORTS</h3>
                    <ul className="space-y-1">
                      {reportTypes
                        .filter(report => report.category === "financial")
                        .map(report => (
                          <li key={report.id}>
                            <button
                              onClick={() => setSelectedReportId(report.id)}
                              className={`w-full text-left px-3 py-2 rounded-md text-sm ${selectedReportId === report.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700 hover:bg-gray-100'}`}
                            >
                              {report.name}
                            </button>
                          </li>
                        ))}
                    </ul>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-2">OUTCOME REPORTS</h3>
                    <ul className="space-y-1">
                      {reportTypes
                        .filter(report => report.category === "outcomes")
                        .map(report => (
                          <li key={report.id}>
                            <button
                              onClick={() => setSelectedReportId(report.id)}
                              className={`w-full text-left px-3 py-2 rounded-md text-sm ${selectedReportId === report.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700 hover:bg-gray-100'}`}
                            >
                              {report.name}
                            </button>
                          </li>
                        ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Report Content */}
          <div className="lg:col-span-3">
            <Card>
              <CardContent className="p-6">
                {renderReportContent()}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
