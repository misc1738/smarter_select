import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AdminHeader } from "../components/AdminHeader";
import { Button } from "../components/Button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/Card";
import { Input } from "../components/Input";
import { Select } from "../components/Select";
import { Separator } from "../components/Separator";

// Type for scholarship form data
interface ScholarshipFormData {
  name: string;
  provider: string;
  category: string;
  amount: string;
  deadline: string;
  description: string;
  eligibility: string[];
  requirements: string[];
  applicationProcess: string;
  difficulty: "easy" | "medium" | "hard";
  isNeedBased: boolean;
  isMeritBased: boolean;
  isDiversityFocused: boolean;
  location: string;
}

export default function ScholarshipForm() {
  const navigate = useNavigate();
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const scholarshipId = searchParams.get('id');
  const isEditing = !!scholarshipId;
  
  // Initial state for the form
  const [formData, setFormData] = useState<ScholarshipFormData>({
    name: "",
    provider: "",
    category: "",
    amount: "",
    deadline: "",
    description: "",
    eligibility: [],
    requirements: [],
    applicationProcess: "",
    difficulty: "medium",
    isNeedBased: false,
    isMeritBased: false,
    isDiversityFocused: false,
    location: "National",
  });
  
  // For managing eligibility criteria inputs
  const [eligibilityCriterion, setEligibilityCriterion] = useState("");
  
  // For managing document requirements inputs
  const [requirementItem, setRequirementItem] = useState("");
  
  // For form submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Mock function to fetch scholarship data if editing
  useEffect(() => {
    if (isEditing) {
      // In a real app, this would fetch the scholarship data from an API
      // For now, we'll simulate with dummy data
      const dummyScholarship: ScholarshipFormData = {
        name: "Future Leaders Scholarship",
        provider: "Leadership Development Institute",
        category: "Leadership",
        amount: "8000",
        deadline: "2025-05-01",
        description: "Scholarship for undergraduate students who have demonstrated exceptional leadership potential through community service, extracurricular activities, or work experience.",
        eligibility: ["Undergraduate students", "GPA 3.0+", "Leadership experience"],
        requirements: ["Transcript", "Resume", "2 Letters of recommendation", "Personal statement"],
        applicationProcess: "Online application with supporting documents",
        difficulty: "medium",
        isNeedBased: false,
        isMeritBased: true,
        isDiversityFocused: false,
        location: "National",
      };
      
      setFormData(dummyScholarship);
    }
  }, [isEditing, scholarshipId]);
  
  // Handle form input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    
    if (type === "checkbox") {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };
  
  // Add eligibility criterion
  const handleAddEligibility = () => {
    if (eligibilityCriterion.trim() !== "") {
      setFormData(prev => ({
        ...prev,
        eligibility: [...prev.eligibility, eligibilityCriterion.trim()]
      }));
      setEligibilityCriterion("");
    }
  };
  
  // Remove eligibility criterion
  const handleRemoveEligibility = (index: number) => {
    setFormData(prev => ({
      ...prev,
      eligibility: prev.eligibility.filter((_, i) => i !== index)
    }));
  };
  
  // Add requirement item
  const handleAddRequirement = () => {
    if (requirementItem.trim() !== "") {
      setFormData(prev => ({
        ...prev,
        requirements: [...prev.requirements, requirementItem.trim()]
      }));
      setRequirementItem("");
    }
  };
  
  // Remove requirement item
  const handleRemoveRequirement = (index: number) => {
    setFormData(prev => ({
      ...prev,
      requirements: prev.requirements.filter((_, i) => i !== index)
    }));
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // In a real app, this would make an API call to save the scholarship
    setTimeout(() => {
      setIsSubmitting(false);
      // Navigate back to the admin dashboard after "saving"
      navigate("/AdminDashboard");
    }, 1000);
  };
  
  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <AdminHeader activeTab="scholarships" />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {isEditing ? "Edit Scholarship" : "Create Scholarship"}
            </h1>
            <p className="text-gray-600 mt-1">
              {isEditing ? "Update the details of this scholarship opportunity" : "Create a new scholarship opportunity for students"}
            </p>
          </div>
          <Button variant="outline" onClick={() => navigate("/AdminDashboard")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Back to Dashboard
          </Button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Main Scholarship Information */}
            <div className="md:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Scholarship Information</CardTitle>
                  <CardDescription>Basic information about the scholarship opportunity</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      label="Scholarship Name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                    />
                    
                    <Input
                      label="Provider/Institution"
                      name="provider"
                      value={formData.provider}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Select
                      label="Category"
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      options={[
                        { value: "", label: "Select a category" },
                        { value: "Leadership", label: "Leadership" },
                        { value: "STEM", label: "STEM" },
                        { value: "Arts", label: "Arts" },
                        { value: "Community Service", label: "Community Service" },
                        { value: "Sports", label: "Sports" },
                        { value: "Diversity", label: "Diversity" },
                        { value: "First Generation", label: "First Generation" },
                        { value: "International", label: "International" },
                        { value: "Healthcare", label: "Healthcare" },
                        { value: "Education", label: "Education" },
                        { value: "Environment", label: "Environment" },
                        { value: "Entrepreneurship", label: "Entrepreneurship" },
                      ]}
                      required
                    />
                    
                    <Input
                      label="Award Amount ($)"
                      name="amount"
                      type="number"
                      min="0"
                      value={formData.amount}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input
                      label="Application Deadline"
                      name="deadline"
                      type="date"
                      value={formData.deadline}
                      onChange={handleChange}
                      required
                    />
                    
                    <Select
                      label="Difficulty Level"
                      name="difficulty"
                      value={formData.difficulty}
                      onChange={handleChange}
                      options={[
                        { value: "easy", label: "Easy - Minimal requirements" },
                        { value: "medium", label: "Medium - Standard requirements" },
                        { value: "hard", label: "Challenging - Extensive requirements" },
                      ]}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1 text-gray-700">
                      Description
                    </label>
                    <textarea
                      name="description"
                      value={formData.description}
                      onChange={handleChange}
                      rows={4}
                      className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium mb-1 text-gray-700">
                      Application Process
                    </label>
                    <textarea
                      name="applicationProcess"
                      value={formData.applicationProcess}
                      onChange={handleChange}
                      rows={2}
                      className="block w-full rounded-md border border-gray-300 shadow-sm py-2 px-3 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                      placeholder="Describe the application process..."
                      required
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Eligibility Criteria</CardTitle>
                  <CardDescription>Define who is eligible for this scholarship</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add an eligibility criterion"
                        value={eligibilityCriterion}
                        onChange={(e) => setEligibilityCriterion(e.target.value)}
                        className="flex-grow"
                      />
                      <Button type="button" onClick={handleAddEligibility}>
                        Add
                      </Button>
                    </div>
                    
                    {formData.eligibility.length > 0 ? (
                      <ul className="space-y-2">
                        {formData.eligibility.map((criterion, index) => (
                          <li key={index} className="flex justify-between items-center bg-gray-50 p-3 rounded">
                            <span>{criterion}</span>
                            <button
                              type="button"
                              onClick={() => handleRemoveEligibility(index)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                            </button>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-gray-500 text-sm">No eligibility criteria added yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Required Documents</CardTitle>
                  <CardDescription>Specify what documents applicants need to submit</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a required document"
                        value={requirementItem}
                        onChange={(e) => setRequirementItem(e.target.value)}
                        className="flex-grow"
                      />
                      <Button type="button" onClick={handleAddRequirement}>
                        Add
                      </Button>
                    </div>
                    
                    {formData.requirements.length > 0 ? (
                      <ul className="space-y-2">
                        {formData.requirements.map((requirement, index) => (
                          <li key={index} className="flex justify-between items-center bg-gray-50 p-3 rounded">
                            <span>{requirement}</span>
                            <button
                              type="button"
                              onClick={() => handleRemoveRequirement(index)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                              </svg>
                            </button>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-gray-500 text-sm">No required documents added yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Sidebar with Additional Options */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Scholarship Type</CardTitle>
                  <CardDescription>Classification of the scholarship</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isNeedBased"
                        name="isNeedBased"
                        checked={formData.isNeedBased}
                        onChange={handleChange}
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <label htmlFor="isNeedBased" className="ml-2 block text-sm text-gray-700">
                        Need-based
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isMeritBased"
                        name="isMeritBased"
                        checked={formData.isMeritBased}
                        onChange={handleChange}
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <label htmlFor="isMeritBased" className="ml-2 block text-sm text-gray-700">
                        Merit-based
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="isDiversityFocused"
                        name="isDiversityFocused"
                        checked={formData.isDiversityFocused}
                        onChange={handleChange}
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <label htmlFor="isDiversityFocused" className="ml-2 block text-sm text-gray-700">
                        Diversity-focused
                      </label>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Location</CardTitle>
                  <CardDescription>Geographic scope of the scholarship</CardDescription>
                </CardHeader>
                <CardContent>
                  <Select
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    options={[
                      { value: "National", label: "National" },
                      { value: "Regional", label: "Regional" },
                      { value: "State", label: "State-specific" },
                      { value: "Local", label: "Local/Community" },
                      { value: "International", label: "International" },
                    ]}
                  />
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Preview & Save</CardTitle>
                  <CardDescription>Review and publish your scholarship</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex flex-col space-y-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => alert("This would show a preview in the real app")}
                    >
                      Preview Scholarship
                    </Button>
                    
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? "Saving..." : isEditing ? "Update Scholarship" : "Create Scholarship"}
                    </Button>
                    
                    {isEditing && (
                      <Button
                        type="button"
                        variant="destructive"
                        onClick={() => {
                          if (confirm("Are you sure you want to delete this scholarship?")) {
                            navigate("/AdminDashboard");
                          }
                        }}
                      >
                        Delete Scholarship
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </main>
    </div>
  );
}
