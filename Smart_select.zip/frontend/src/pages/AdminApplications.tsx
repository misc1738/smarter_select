import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminHeader } from "../components/AdminHeader";
import { Button } from "../components/Button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/Card";
import { Input } from "../components/Input";
import { Select } from "../components/Select";
import { Badge } from "../components/Badge";

type ApplicationStatus = "submitted" | "under_review" | "approved" | "rejected" | "pending_documents";

interface Application {
  id: string;
  studentName: string;
  email: string;
  scholarshipName: string;
  status: ApplicationStatus;
  submittedAt: string;
  lastUpdated: string;
}

// Helper function to format dates
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

// Mock data for applications
const mockApplications: Application[] = [
  {
    id: "app-001",
    studentName: "Michael Johnson",
    email: "michael.johnson@example.com",
    scholarshipName: "Future Leaders Scholarship",
    status: "under_review",
    submittedAt: "2025-02-10",
    lastUpdated: "2025-02-15",
  },
  {
    id: "app-002",
    studentName: "Sarah Williams",
    email: "sarah.williams@example.com",
    scholarshipName: "Arts & Humanities Grant",
    status: "approved",
    submittedAt: "2025-01-25",
    lastUpdated: "2025-02-12",
  },
  {
    id: "app-003",
    studentName: "James Davis",
    email: "james.davis@example.com",
    scholarshipName: "Women in STEM Scholarship",
    status: "rejected",
    submittedAt: "2025-02-05",
    lastUpdated: "2025-02-18",
  },
  {
    id: "app-004",
    studentName: "Emily Wilson",
    email: "emily.wilson@example.com",
    scholarshipName: "First Generation College Award",
    status: "pending_documents",
    submittedAt: "2025-02-12",
    lastUpdated: "2025-02-14",
  },
  {
    id: "app-005",
    studentName: "Daniel Brown",
    email: "daniel.brown@example.com",
    scholarshipName: "Community Service Excellence",
    status: "submitted",
    submittedAt: "2025-02-20",
    lastUpdated: "2025-02-20",
  },
  {
    id: "app-006",
    studentName: "Jennifer Miller",
    email: "jennifer.miller@example.com",
    scholarshipName: "Environmental Studies Grant",
    status: "under_review",
    submittedAt: "2025-02-01",
    lastUpdated: "2025-02-10",
  },
  {
    id: "app-007",
    studentName: "Robert Taylor",
    email: "robert.taylor@example.com",
    scholarshipName: "Future Leaders Scholarship",
    status: "approved",
    submittedAt: "2025-01-15",
    lastUpdated: "2025-02-03",
  },
  {
    id: "app-008",
    studentName: "Jessica Rodriguez",
    email: "jessica.rodriguez@example.com",
    scholarshipName: "Healthcare Professionals Fund",
    status: "under_review",
    submittedAt: "2025-02-08",
    lastUpdated: "2025-02-17",
  },
  {
    id: "app-009",
    studentName: "Thomas Anderson",
    email: "thomas.anderson@example.com",
    scholarshipName: "Technical Innovation Award",
    status: "submitted",
    submittedAt: "2025-02-22",
    lastUpdated: "2025-02-22",
  },
  {
    id: "app-010",
    studentName: "Lisa Martinez",
    email: "lisa.martinez@example.com",
    scholarshipName: "Minority Student Empowerment",
    status: "pending_documents",
    submittedAt: "2025-02-15",
    lastUpdated: "2025-02-16",
  },
];

// Function to get status badge based on application status
const getStatusBadge = (status: ApplicationStatus) => {
  switch (status) {
    case "submitted":
      return <Badge variant="secondary">Submitted</Badge>;
    case "under_review":
      return <Badge variant="primary">Under Review</Badge>;
    case "approved":
      return <Badge variant="success">Approved</Badge>;
    case "rejected":
      return <Badge variant="destructive">Rejected</Badge>;
    case "pending_documents":
      return <Badge variant="warning">Pending Documents</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
};

export default function AdminApplications() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [scholarshipFilter, setScholarshipFilter] = useState("");
  
  // Get unique scholarship names for filter dropdown
  const scholarshipNames = Array.from(new Set(mockApplications.map(app => app.scholarshipName)));
  
  // Filter applications based on search term and filters
  const filteredApplications = mockApplications.filter(application => {
    const matchesSearch = 
      application.studentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      application.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      application.scholarshipName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "" || application.status === statusFilter;
    const matchesScholarship = scholarshipFilter === "" || application.scholarshipName === scholarshipFilter;
    
    return matchesSearch && matchesStatus && matchesScholarship;
  });

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <AdminHeader activeTab="applications" />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Manage Applications</h1>
            <p className="text-gray-600 mt-1">Review, process and track scholarship applications</p>
          </div>
          <Button variant="outline" onClick={() => navigate("/AdminDashboard")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            Dashboard
          </Button>
        </div>
        
        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Filter applications by various criteria</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Input
                label="Search"
                placeholder="Search by student name or email"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              
              <Select
                label="Scholarship"
                value={scholarshipFilter}
                onChange={(e) => setScholarshipFilter(e.target.value)}
                options={[
                  { value: "", label: "All Scholarships" },
                  ...scholarshipNames.map(name => ({ value: name, label: name }))
                ]}
              />
              
              <Select
                label="Status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                options={[
                  { value: "", label: "All Statuses" },
                  { value: "submitted", label: "Submitted" },
                  { value: "under_review", label: "Under Review" },
                  { value: "approved", label: "Approved" },
                  { value: "rejected", label: "Rejected" },
                  { value: "pending_documents", label: "Pending Documents" },
                ]}
              />
            </div>
          </CardContent>
        </Card>
        
        {/* Applications Table */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Applications</CardTitle>
              <p className="text-sm text-gray-500">{filteredApplications.length} applications found</p>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-md border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-gray-50">
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Student</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Scholarship</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Status</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Submitted</th>
                    <th className="py-3 px-4 text-left font-medium text-gray-500">Last Updated</th>
                    <th className="py-3 px-4 text-right font-medium text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredApplications.map((application) => (
                    <tr key={application.id} className="hover:bg-gray-50">
                      <td className="py-3 px-4">
                        <div className="font-medium text-gray-900">{application.studentName}</div>
                        <div className="text-gray-500 text-xs">{application.email}</div>
                      </td>
                      <td className="py-3 px-4 text-gray-700">{application.scholarshipName}</td>
                      <td className="py-3 px-4">{getStatusBadge(application.status)}</td>
                      <td className="py-3 px-4 text-gray-500">{formatDate(application.submittedAt)}</td>
                      <td className="py-3 px-4 text-gray-500">{formatDate(application.lastUpdated)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            onClick={() => navigate(`/ApplicationDetail?id=${application.id}`)}
                          >
                            Review
                          </Button>
                          <Button 
                            size="sm" 
                            variant="secondary"
                            onClick={() => alert(`Message student ${application.studentName}. This would open a message dialog in the real app.`)}
                          >
                            Message
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
