import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Header } from "../components/Header";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/Card";
import { Button } from "../components/Button";
import { Badge } from "../components/Badge";
import { Separator } from "../components/Separator";
import { Pagination } from "../components/Pagination";
import { Select } from "../components/Select";
import { Input } from "../components/Input";
import { Checkbox } from "../components/Checkbox";

// Define scholarship interface
interface Scholarship {
  id: string;
  name: string;
  provider: string;
  amount: string;
  description: string;
  deadline: string;
  eligibility: string[];
  category: string;
  requirements: string[];
  applicationProcess: string;
  difficulty: "easy" | "medium" | "hard";
  isNeedBased: boolean;
  isMeritBased: boolean;
  isDiversityFocused: boolean;
  location: string;
  createdAt: string;
}

// Mock data for scholarships
const mockScholarships: Scholarship[] = [
  {
    id: "sch-001",
    name: "Future Leaders Scholarship",
    provider: "Leadership Development Institute",
    amount: "$8,000",
    description: "Scholarship for undergraduate students who have demonstrated exceptional leadership potential through community service, extracurricular activities, or work experience.",
    deadline: "2025-05-01",
    eligibility: ["Undergraduate students", "GPA 3.0+", "Leadership experience"],
    category: "Leadership",
    requirements: ["Transcript", "Resume", "2 Letters of recommendation", "Personal statement"],
    applicationProcess: "Online application with supporting documents",
    difficulty: "medium",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2024-12-01"
  },
  {
    id: "sch-002",
    name: "Arts & Humanities Grant",
    provider: "Creative Arts Foundation",
    amount: "$3,500",
    description: "Financial support for students pursuing degrees in arts, humanities, literature, or cultural studies. Recipients are selected based on creative portfolio and academic achievement.",
    deadline: "2025-05-15",
    eligibility: ["Arts/Humanities majors", "GPA 3.2+", "Portfolio submission"],
    category: "Arts",
    requirements: ["Transcript", "Creative portfolio", "Essay"],
    applicationProcess: "Two-stage application with portfolio review",
    difficulty: "medium",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2024-12-05"
  },
  {
    id: "sch-003",
    name: "Diversity Advancement Scholarship",
    provider: "Inclusive Education Initiative",
    amount: "$5,500",
    description: "Scholarship program designed to support students from underrepresented backgrounds who are pursuing degrees in fields where their demographics are traditionally underrepresented.",
    deadline: "2025-06-01",
    eligibility: ["Underrepresented groups", "Any major", "Demonstrated commitment to diversity"],
    category: "Diversity",
    requirements: ["Transcript", "Personal statement", "Diversity essay"],
    applicationProcess: "Online application with supporting documents",
    difficulty: "medium",
    isNeedBased: true,
    isMeritBased: false,
    isDiversityFocused: true,
    location: "National",
    createdAt: "2024-12-10"
  },
  {
    id: "sch-004",
    name: "STEM Excellence Award",
    provider: "National Science Foundation",
    amount: "$10,000",
    description: "Prestigious award for outstanding students in Science, Technology, Engineering, and Mathematics fields who have demonstrated exceptional academic achievement and research potential.",
    deadline: "2025-04-15",
    eligibility: ["STEM majors", "GPA 3.5+", "Research experience"],
    category: "STEM",
    requirements: ["Transcript", "Research proposal", "Faculty recommendation"],
    applicationProcess: "Competitive application with interview",
    difficulty: "hard",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2024-11-20"
  },
  {
    id: "sch-005",
    name: "First Generation Scholars Program",
    provider: "Education Access Foundation",
    amount: "$6,500",
    description: "Scholarship program dedicated to supporting first-generation college students who are the first in their families to pursue higher education.",
    deadline: "2025-05-30",
    eligibility: ["First-generation students", "Financial need", "Any major"],
    category: "First Generation",
    requirements: ["Transcript", "Financial information", "Personal statement"],
    applicationProcess: "Online application with supporting documents",
    difficulty: "medium",
    isNeedBased: true,
    isMeritBased: false,
    isDiversityFocused: true,
    location: "National",
    createdAt: "2024-12-15"
  },
  {
    id: "sch-006",
    name: "Community Service Scholarship",
    provider: "Community Foundation",
    amount: "$4,000",
    description: "Recognition for students with an exceptional commitment to community service and volunteerism, who have made a positive impact in their communities.",
    deadline: "2025-04-30",
    eligibility: ["100+ volunteer hours", "Any major", "Demonstrated impact"],
    category: "Community Service",
    requirements: ["Volunteer verification", "Impact statement", "Reference letter"],
    applicationProcess: "Online application with verification",
    difficulty: "easy",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2024-12-20"
  },
  {
    id: "sch-007",
    name: "International Student Award",
    provider: "Global Education Alliance",
    amount: "$7,500",
    description: "Financial assistance for international students who demonstrate academic excellence and have financial need to pursue their studies in the United States.",
    deadline: "2025-03-15",
    eligibility: ["International students", "GPA 3.3+", "Financial need"],
    category: "International",
    requirements: ["Transcript", "Financial documentation", "Essay"],
    applicationProcess: "Online application with document verification",
    difficulty: "medium",
    isNeedBased: true,
    isMeritBased: true,
    isDiversityFocused: true,
    location: "National",
    createdAt: "2024-11-10"
  },
  {
    id: "sch-008",
    name: "Healthcare Professionals Scholarship",
    provider: "Medical Education Fund",
    amount: "$9,000",
    description: "Support for students pursuing careers in healthcare fields including medicine, nursing, public health, and allied health professions.",
    deadline: "2025-06-15",
    eligibility: ["Healthcare majors", "GPA 3.0+", "Clinical experience preferred"],
    category: "Healthcare",
    requirements: ["Transcript", "Personal statement", "Career goals essay"],
    applicationProcess: "Online application with optional interview",
    difficulty: "medium",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2025-01-05"
  },
  {
    id: "sch-009",
    name: "Environmental Studies Grant",
    provider: "Green Future Foundation",
    amount: "$5,000",
    description: "Funding for students committed to environmental protection, sustainability, conservation, or related fields who want to make a positive impact on the planet.",
    deadline: "2025-05-22",
    eligibility: ["Environmental focus", "Any major", "Demonstrated commitment"],
    category: "Environment",
    requirements: ["Transcript", "Environmental project proposal", "Reference letter"],
    applicationProcess: "Online application with project review",
    difficulty: "medium",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2025-01-10"
  },
  {
    id: "sch-010",
    name: "Entrepreneurship Fellowship",
    provider: "Innovation Institute",
    amount: "$12,000",
    description: "Support for student entrepreneurs with innovative business ideas or startups. Includes mentorship and networking opportunities in addition to financial award.",
    deadline: "2025-04-01",
    eligibility: ["Business plan/startup", "Any major", "Demonstrated entrepreneurial spirit"],
    category: "Entrepreneurship",
    requirements: ["Business plan", "Pitch deck", "Financial projections"],
    applicationProcess: "Multi-stage with business plan review and pitch",
    difficulty: "hard",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2024-11-30"
  },
  {
    id: "sch-011",
    name: "Teaching Career Scholarship",
    provider: "Education Tomorrow Fund",
    amount: "$6,000",
    description: "Financial assistance for students pursuing careers in education and teaching, with a commitment to working in underserved schools after graduation.",
    deadline: "2025-05-10",
    eligibility: ["Education majors", "GPA 3.0+", "Commitment to teaching"],
    category: "Education",
    requirements: ["Transcript", "Personal statement", "Teaching philosophy"],
    applicationProcess: "Online application with possible teaching demonstration",
    difficulty: "medium",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2025-01-15"
  },
  {
    id: "sch-012",
    name: "Performing Arts Scholarship",
    provider: "Arts Council",
    amount: "$4,500",
    description: "Support for talented students in music, theater, dance, or other performing arts disciplines who demonstrate exceptional artistic ability.",
    deadline: "2025-06-30",
    eligibility: ["Performing arts focus", "Audition required", "Any GPA"],
    category: "Arts",
    requirements: ["Performance video", "Artistic resume", "Personal statement"],
    applicationProcess: "Application with audition/portfolio review",
    difficulty: "medium",
    isNeedBased: false,
    isMeritBased: true,
    isDiversityFocused: false,
    location: "National",
    createdAt: "2025-01-20"
  }
];

// Helper function to format dates
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

// Helper function to get days until deadline
const getDaysUntil = (dateString: string) => {
  const today = new Date();
  const deadline = new Date(dateString);
  const diffTime = deadline.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

// Helper function to get difficulty badge
const getDifficultyBadge = (difficulty: string) => {
  switch (difficulty) {
    case "easy":
      return <Badge variant="success">Easy</Badge>;
    case "medium":
      return <Badge variant="warning">Medium</Badge>;
    case "hard":
      return <Badge variant="destructive">Challenging</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
};

export default function Scholarships() {
  const navigate = useNavigate();
  const [isLoggedIn] = useState(false); // Would come from auth in a real app
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedAmount, setSelectedAmount] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState("");
  const [needBased, setNeedBased] = useState(false);
  const [meritBased, setMeritBased] = useState(false);
  const [diversityFocused, setDiversityFocused] = useState(false);
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const scholarshipsPerPage = 6;
  
  // Filter scholarships based on criteria
  const filteredScholarships = mockScholarships.filter(scholarship => {
    // Search term filter
    if (searchTerm && !scholarship.name.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !scholarship.description.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !scholarship.provider.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Category filter
    if (selectedCategory && scholarship.category !== selectedCategory) {
      return false;
    }
    
    // Amount filter
    if (selectedAmount) {
      const amount = parseInt(scholarship.amount.replace(/[^0-9]/g, ''));
      if (selectedAmount === "Under $5,000" && amount >= 5000) return false;
      if (selectedAmount === "$5,000 - $10,000" && (amount < 5000 || amount > 10000)) return false;
      if (selectedAmount === "Over $10,000" && amount <= 10000) return false;
    }
    
    // Difficulty filter
    if (selectedDifficulty && scholarship.difficulty !== selectedDifficulty) {
      return false;
    }
    
    // Type filters
    if (needBased && !scholarship.isNeedBased) return false;
    if (meritBased && !scholarship.isMeritBased) return false;
    if (diversityFocused && !scholarship.isDiversityFocused) return false;
    
    return true;
  });
  
  // Get current scholarships for pagination
  const indexOfLastScholarship = currentPage * scholarshipsPerPage;
  const indexOfFirstScholarship = indexOfLastScholarship - scholarshipsPerPage;
  const currentScholarships = filteredScholarships.slice(indexOfFirstScholarship, indexOfLastScholarship);
  const totalPages = Math.ceil(filteredScholarships.length / scholarshipsPerPage);
  
  // Get unique categories for filter
  const categories = Array.from(new Set(mockScholarships.map(s => s.category)));
  
  // Handle page change
  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
    window.scrollTo(0, 0);
  };
  
  // Handle filter reset
  const handleResetFilters = () => {
    setSearchTerm("");
    setSelectedCategory("");
    setSelectedAmount("");
    setSelectedDifficulty("");
    setNeedBased(false);
    setMeritBased(false);
    setDiversityFocused(false);
    setCurrentPage(1);
  };
  
  // Handle apply button click
  const handleApply = (scholarshipId: string) => {
    navigate(`/ApplicationForm?scholarshipId=${scholarshipId}`);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header isLoggedIn={isLoggedIn} />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Available Scholarships</h1>
          <p className="text-lg text-gray-600">Browse and filter scholarship opportunities to find the perfect match for your academic journey.</p>
        </div>
        
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Filters sidebar */}
          <div className="lg:w-1/4 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Filter Scholarships</CardTitle>
                <CardDescription>Refine your search to find relevant opportunities</CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                <Input
                  type="text"
                  placeholder="Search by keyword"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  label="Search"
                />
                
                <Select
                  label="Category"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  options={[
                    { value: "", label: "All Categories" },
                    ...categories.map(cat => ({ value: cat, label: cat }))
                  ]}
                />
                
                <Select
                  label="Award Amount"
                  value={selectedAmount}
                  onChange={(e) => setSelectedAmount(e.target.value)}
                  options={[
                    { value: "", label: "Any Amount" },
                    { value: "Under $5,000", label: "Under $5,000" },
                    { value: "$5,000 - $10,000", label: "$5,000 - $10,000" },
                    { value: "Over $10,000", label: "Over $10,000" }
                  ]}
                />
                
                <Select
                  label="Application Difficulty"
                  value={selectedDifficulty}
                  onChange={(e) => setSelectedDifficulty(e.target.value)}
                  options={[
                    { value: "", label: "Any Difficulty" },
                    { value: "easy", label: "Easy" },
                    { value: "medium", label: "Medium" },
                    { value: "hard", label: "Challenging" }
                  ]}
                />
                
                <div>
                  <p className="block text-sm font-medium mb-2 text-gray-700">Scholarship Type</p>
                  <div className="space-y-2">
                    <Checkbox
                      id="need-based"
                      label="Need-based"
                      checked={needBased}
                      onChange={() => setNeedBased(!needBased)}
                    />
                    <Checkbox
                      id="merit-based"
                      label="Merit-based"
                      checked={meritBased}
                      onChange={() => setMeritBased(!meritBased)}
                    />
                    <Checkbox
                      id="diversity-focused"
                      label="Diversity-focused"
                      checked={diversityFocused}
                      onChange={() => setDiversityFocused(!diversityFocused)}
                    />
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button 
                  variant="outline" 
                  className="w-full" 
                  onClick={handleResetFilters}
                >
                  Reset Filters
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Need Help?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">Not sure which scholarships to apply for? Our scholarship advisors can help guide you.</p>
                <Button 
                  variant="secondary" 
                  className="w-full"
                  onClick={() => navigate("/Resources")}
                >
                  Schedule Advising
                </Button>
              </CardContent>
            </Card>
          </div>
          
          {/* Scholarship listings */}
          <div className="lg:w-3/4">
            <div className="mb-4 flex items-center justify-between">
              <p className="text-gray-600">
                Showing <span className="font-medium">{indexOfFirstScholarship + 1}-{Math.min(indexOfLastScholarship, filteredScholarships.length)}</span> of <span className="font-medium">{filteredScholarships.length}</span> scholarships
              </p>
              <Select
                className="w-40"
                value="deadline"
                options={[
                  { value: "deadline", label: "Deadline" },
                  { value: "amount", label: "Amount" },
                  { value: "name", label: "Name" }
                ]}
              />
            </div>
            
            {currentScholarships.length > 0 ? (
              <div className="space-y-6">
                {currentScholarships.map((scholarship) => (
                  <Card key={scholarship.id} className="overflow-hidden hover:shadow-md transition">
                    <div className="flex flex-col md:flex-row">
                      <div className="md:w-3/4 p-6">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-xl font-semibold text-gray-900">{scholarship.name}</h3>
                            <p className="text-gray-600">{scholarship.provider}</p>
                          </div>
                          <div className="flex items-center space-x-2">
                            {getDifficultyBadge(scholarship.difficulty)}
                            {scholarship.isNeedBased && <Badge variant="secondary">Need-based</Badge>}
                          </div>
                        </div>
                        
                        <p className="mt-3 text-gray-700">{scholarship.description}</p>
                        
                        <div className="mt-4 flex flex-wrap gap-2">
                          {scholarship.eligibility.map((item, index) => (
                            <Badge key={index} variant="outline">{item}</Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div className="md:w-1/4 bg-gray-50 flex flex-col p-6 justify-between border-t md:border-t-0 md:border-l">
                        <div>
                          <div className="text-center mb-4">
                            <p className="text-sm text-gray-600 mb-1">Award Amount</p>
                            <p className="text-2xl font-bold text-primary">{scholarship.amount}</p>
                          </div>
                          
                          <div className="text-center">
                            <p className="text-sm text-gray-600 mb-1">Application Deadline</p>
                            <p className="font-medium">{formatDate(scholarship.deadline)}</p>
                            <p className="text-sm text-amber-600 mt-1">
                              {getDaysUntil(scholarship.deadline) > 0 
                                ? `${getDaysUntil(scholarship.deadline)} days left` 
                                : "Deadline passed"}
                            </p>
                          </div>
                        </div>
                        
                        <Button 
                          className="mt-6 w-full" 
                          onClick={() => handleApply(scholarship.id)}
                          disabled={getDaysUntil(scholarship.deadline) <= 0}
                        >
                          Apply Now
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
                
                {/* Pagination */}
                {totalPages > 1 && (
                  <Pagination 
                    currentPage={currentPage} 
                    totalPages={totalPages} 
                    onPageChange={handlePageChange} 
                  />
                )}
              </div>
            ) : (
              <div className="bg-gray-50 border rounded-lg p-8 text-center">
                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="mt-4 text-lg font-medium text-gray-900">No scholarships found</h3>
                <p className="mt-2 text-gray-600">We couldn't find any scholarships matching your criteria. Try adjusting your filters.</p>
                <Button 
                  className="mt-4" 
                  onClick={handleResetFilters}
                >
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
