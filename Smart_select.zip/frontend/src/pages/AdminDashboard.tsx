import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminHeader } from "../components/AdminHeader";
import { Button } from "../components/Button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/Card";
import { StatsCard } from "../components/StatsCard";
import { ScholarshipTable } from "../components/ScholarshipTable";
import { Separator } from "../components/Separator";

// Mock data for scholarship statistics
const dashboardStats = {
  totalScholarships: 24,
  totalScholarshipsChange: "+8% from last month",
  activeScholarships: 16,
  activeScholarshipsChange: "+4% from last month",
  totalApplicants: 1874,
  totalApplicantsChange: "+12% from last month",
  applicationsThisWeek: 89,
  applicationsThisWeekChange: "-5% from last week",
  pendingReviews: 42,
  pendingReviewsChange: "+7% from last week",
  approvalRate: "68%",
  approvalRateChange: "+3% from last month",
};

// Mock data for recent scholarships
const recentScholarships = [
  {
    id: "sch-001",
    name: "Future Leaders Scholarship",
    category: "Leadership",
    amount: "$8,000",
    status: "published" as const,
    deadline: "2025-05-01",
    applicants: 165,
    createdAt: "2024-12-01",
  },
  {
    id: "sch-002",
    name: "Arts & Humanities Grant",
    category: "Arts",
    amount: "$3,500",
    status: "published" as const,
    deadline: "2025-05-15",
    applicants: 78,
    createdAt: "2024-12-05",
  },
  {
    id: "sch-013",
    name: "Technical Innovation Award",
    category: "STEM",
    amount: "$5,000",
    status: "draft" as const,
    deadline: "2025-07-15",
    applicants: 0,
    createdAt: "2025-01-25",
  },
  {
    id: "sch-010",
    name: "Entrepreneurship Fellowship",
    category: "Entrepreneurship",
    amount: "$12,000",
    status: "published" as const,
    deadline: "2025-04-01",
    applicants: 112,
    createdAt: "2024-11-30",
  },
  {
    id: "sch-007",
    name: "International Student Award",
    category: "International",
    amount: "$7,500",
    status: "archived" as const,
    deadline: "2025-03-15",
    applicants: 203,
    createdAt: "2024-11-10",
  },
];

export default function AdminDashboard() {
  const navigate = useNavigate();
  
  // Handler functions for scholarship actions
  const handleEditScholarship = (id: string) => {
    navigate(`/ScholarshipForm?id=${id}`);
  };
  
  const handleDeleteScholarship = (id: string) => {
    // In a real app, this would show a confirmation dialog and make an API call
    alert(`Deleting scholarship ${id}. This would be a confirmation dialog in the real app.`);
  };
  
  const handlePublishScholarship = (id: string) => {
    // In a real app, this would make an API call
    alert(`Publishing scholarship ${id}. This would update the status in the real app.`);
  };
  
  const handleArchiveScholarship = (id: string) => {
    // In a real app, this would make an API call
    alert(`Archiving scholarship ${id}. This would update the status in the real app.`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <AdminHeader activeTab="dashboard" />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-600 mt-1">Manage scholarships and monitor application activity</p>
          </div>
          <Button onClick={() => navigate("/ScholarshipForm")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Create Scholarship
          </Button>
        </div>
        
        {/* Dashboard Stats Grid */}
        <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 mb-8">
          <StatsCard 
            title="Total Scholarships" 
            value={dashboardStats.totalScholarships}
            change={{ value: dashboardStats.totalScholarshipsChange, positive: true }}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>}
          />
          
          <StatsCard 
            title="Active Scholarships" 
            value={dashboardStats.activeScholarships}
            change={{ value: dashboardStats.activeScholarshipsChange, positive: true }}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>}
          />
          
          <StatsCard 
            title="Total Applicants" 
            value={dashboardStats.totalApplicants}
            change={{ value: dashboardStats.totalApplicantsChange, positive: true }}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>}
          />
          
          <StatsCard 
            title="New Applications (This Week)" 
            value={dashboardStats.applicationsThisWeek}
            change={{ value: dashboardStats.applicationsThisWeekChange, positive: false }}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>}
          />
          
          <StatsCard 
            title="Pending Reviews" 
            value={dashboardStats.pendingReviews}
            change={{ value: dashboardStats.pendingReviewsChange, positive: true }}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
            </svg>}
          />
          
          <StatsCard 
            title="Approval Rate" 
            value={dashboardStats.approvalRate}
            change={{ value: dashboardStats.approvalRateChange, positive: true }}
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
            </svg>}
          />
        </div>

        {/* Application Status Distribution Chart */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Application Status Distribution</CardTitle>
            <CardDescription>Overall distribution of application statuses across all scholarships</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80 flex items-center justify-center text-gray-500">
              {/* In a real app, this would be a chart component */}
              <div className="text-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                </svg>
                <p className="mt-2">Chart visualization would appear here<br />showing application status distribution</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Scholarships Table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Scholarships</CardTitle>
                <CardDescription>Manage your recently created scholarship opportunities</CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => navigate("/AdminScholarships")}>
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScholarshipTable 
              scholarships={recentScholarships}
              onEdit={handleEditScholarship}
              onDelete={handleDeleteScholarship}
              onPublish={handlePublishScholarship}
              onArchive={handleArchiveScholarship}
            />
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
