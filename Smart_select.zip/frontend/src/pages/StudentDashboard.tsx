import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "../components/Card";
import { Badge } from "../components/Badge";
import { Button } from "../components/Button";
import { Progress } from "../components/Progress";
import { Separator } from "../components/Separator";
import { Avatar, AvatarFallback, AvatarImage } from "../components/Avatar";

// Mock data for scholarship applications
const activeApplications = [
  {
    id: "app-001",
    scholarshipName: "Academic Excellence Scholarship",
    institution: "University of Excellence",
    deadline: "2025-04-15",
    status: "pending",
    progress: 65,
    description: "Merit-based scholarship for outstanding academic achievement",
    amount: "$5,000",
    requiredDocs: ["Transcript", "Recommendation Letter", "Essay"],
    submittedDocs: ["Transcript", "Recommendation Letter"],
  },
  {
    id: "app-002",
    scholarshipName: "STEM Leaders Scholarship",
    institution: "National Science Foundation",
    deadline: "2025-03-30",
    status: "review",
    progress: 85,
    description: "Scholarship for students pursuing degrees in STEM fields",
    amount: "$7,500",
    requiredDocs: ["Transcript", "Research Proposal", "Recommendation Letter"],
    submittedDocs: ["Transcript", "Research Proposal", "Recommendation Letter"],
  },
  {
    id: "app-003",
    scholarshipName: "Community Leadership Award",
    institution: "Regional Community Foundation",
    deadline: "2025-04-10",
    status: "pending",
    progress: 40,
    description: "Scholarship recognizing exceptional community service",
    amount: "$3,000",
    requiredDocs: ["Community Service Log", "Personal Statement", "Reference Letters"],
    submittedDocs: ["Community Service Log"],
  },
];

const completedApplications = [
  {
    id: "app-004",
    scholarshipName: "Global Citizens Scholarship",
    institution: "International Education Alliance",
    completedDate: "2025-02-20",
    status: "approved",
    amount: "$4,000",
    description: "Scholarship for students demonstrating global awareness",
  },
  {
    id: "app-005",
    scholarshipName: "First Generation Scholars Program",
    institution: "Education Access Foundation",
    completedDate: "2025-02-05",
    status: "rejected",
    amount: "$6,500",
    description: "Support for first-generation college students",
  },
];

const upcomingDeadlines = [
  {
    id: "sch-001",
    scholarshipName: "Future Leaders Scholarship",
    institution: "Leadership Development Institute",
    deadline: "2025-05-01",
    amount: "$8,000",
    description: "Scholarship for students with leadership potential",
  },
  {
    id: "sch-002",
    scholarshipName: "Arts & Humanities Grant",
    institution: "Creative Arts Foundation",
    deadline: "2025-05-15",
    amount: "$3,500",
    description: "Support for students in arts and humanities programs",
  },
  {
    id: "sch-003",
    scholarshipName: "Diversity Advancement Scholarship",
    institution: "Inclusive Education Initiative",
    deadline: "2025-06-01",
    amount: "$5,500",
    description: "Scholarship promoting diversity in higher education",
  },
];

// Helper function to format dates
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

// Helper function to determine days until deadline
const getDaysUntil = (dateString: string) => {
  const today = new Date();
  const deadline = new Date(dateString);
  const diffTime = deadline.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
};

// Helper function to get status badge
const getStatusBadge = (status: string) => {
  switch (status) {
    case "pending":
      return <Badge variant="pending">Pending</Badge>;
    case "review":
      return <Badge variant="review">Under Review</Badge>;
    case "approved":
      return <Badge variant="approved">Approved</Badge>;
    case "rejected":
      return <Badge variant="rejected">Rejected</Badge>;
    default:
      return <Badge variant="secondary">Unknown</Badge>;
  }
};

export default function StudentDashboard() {
  const navigate = useNavigate();
  const [studentName] = useState("Alex Johnson"); // Would come from auth in a real app

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <Avatar className="h-12 w-12">
            <AvatarImage src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80" />
            <AvatarFallback>AJ</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-bold">Welcome, {studentName}</h1>
            <p className="text-muted-foreground">Manage your scholarship applications</p>
          </div>
        </div>
        <Button onClick={() => navigate("/ApplicationForm")}>
          Apply for Scholarship
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Active Applications</CardTitle>
            <CardDescription>{activeApplications.length} scholarships in progress</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{activeApplications.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Completed Applications</CardTitle>
            <CardDescription>Total applications submitted</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{completedApplications.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Upcoming Deadlines</CardTitle>
            <CardDescription>Scholarships to apply for</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{upcomingDeadlines.length}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <div className="col-span-1 md:col-span-8 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Applications</CardTitle>
              <CardDescription>
                Scholarships you are currently applying for
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {activeApplications.map((app) => (
                  <div key={app.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-semibold">{app.scholarshipName}</h3>
                        <p className="text-sm text-muted-foreground">{app.institution}</p>
                      </div>
                      {getStatusBadge(app.status)}
                    </div>
                    <div className="mt-2">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Application Progress</span>
                        <span>{app.progress}%</span>
                      </div>
                      <Progress value={app.progress} className="h-2" />
                    </div>
                    <div className="mt-4 flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="text-sm">
                          <span className="text-muted-foreground">Deadline: </span>
                          <span className="font-medium">{formatDate(app.deadline)}</span>
                          <span className="ml-2 text-xs text-amber-600">
                            ({getDaysUntil(app.deadline)} days left)
                          </span>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => navigate(`/ApplicationDetail/${app.id}`)}
                      >
                        Continue
                      </Button>
                    </div>
                    <div className="mt-3 text-xs">
                      <div className="text-muted-foreground">Documents:</div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {app.requiredDocs.map((doc) => (
                          <Badge 
                            key={doc} 
                            variant={app.submittedDocs.includes(doc) ? "success" : "outline"}
                            className="text-xs"
                          >
                            {doc}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm" onClick={() => navigate("/AllApplications")}>
                View All Applications
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Completed Applications</CardTitle>
              <CardDescription>
                Your scholarship application results
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {completedApplications.map((app) => (
                  <div key={app.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">{app.scholarshipName}</h3>
                        <p className="text-sm text-muted-foreground">{app.institution}</p>
                      </div>
                      {getStatusBadge(app.status)}
                    </div>
                    <div className="mt-2 text-sm">
                      <span className="text-muted-foreground">Completed: </span>
                      <span>{formatDate(app.completedDate)}</span>
                    </div>
                    <div className="mt-4 flex justify-between items-center">
                      <div className="text-sm">
                        <span className="text-muted-foreground">Amount: </span>
                        <span className="font-medium">{app.amount}</span>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate(`/ApplicationDetail/${app.id}`)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="col-span-1 md:col-span-4 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Deadlines</CardTitle>
              <CardDescription>
                Scholarships you might be interested in
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingDeadlines.map((scholarship) => (
                  <div key={scholarship.id} className="border rounded-lg p-4">
                    <h3 className="font-semibold">{scholarship.scholarshipName}</h3>
                    <p className="text-sm text-muted-foreground">{scholarship.institution}</p>
                    <div className="mt-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Deadline: </span>
                        <span className="font-medium">{formatDate(scholarship.deadline)}</span>
                      </div>
                      <div className="mt-1">
                        <span className="text-muted-foreground">Amount: </span>
                        <span>{scholarship.amount}</span>
                      </div>
                    </div>
                    <div className="mt-2 text-sm text-muted-foreground truncate">
                      {scholarship.description}
                    </div>
                    <div className="mt-4">
                      <Button 
                        size="sm" 
                        className="w-full"
                        onClick={() => navigate(`/ApplicationForm?scholarshipId=${scholarship.id}`)}
                      >
                        Apply Now
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" size="sm" className="w-full" onClick={() => navigate("/Scholarships")}>
                Browse All Scholarships
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Application Tips</CardTitle>
              <CardDescription>
                Improve your chances of success
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 text-sm">
                <li className="flex gap-2">
                  <div className="rounded-full h-5 w-5 flex items-center justify-center bg-primary text-primary-foreground text-xs font-bold">
                    1
                  </div>
                  <span>Complete your profile to unlock personalized scholarship recommendations</span>
                </li>
                <li className="flex gap-2">
                  <div className="rounded-full h-5 w-5 flex items-center justify-center bg-primary text-primary-foreground text-xs font-bold">
                    2
                  </div>
                  <span>Submit applications at least 48 hours before the deadline</span>
                </li>
                <li className="flex gap-2">
                  <div className="rounded-full h-5 w-5 flex items-center justify-center bg-primary text-primary-foreground text-xs font-bold">
                    3
                  </div>
                  <span>Thoroughly proofread all essays and statements</span>
                </li>
                <li className="flex gap-2">
                  <div className="rounded-full h-5 w-5 flex items-center justify-center bg-primary text-primary-foreground text-xs font-bold">
                    4
                  </div>
                  <span>Request recommendation letters at least two weeks in advance</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
