import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminHeader } from "../components/AdminHeader";
import { Button } from "../components/Button";
import { ScholarshipTable } from "../components/ScholarshipTable";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/Card";
import { Input } from "../components/Input";
import { Select } from "../components/Select";

// Mock data for scholarships
const allScholarships = [
  {
    id: "sch-001",
    name: "Future Leaders Scholarship",
    category: "Leadership",
    amount: "$8,000",
    status: "published" as const,
    deadline: "2025-05-01",
    applicants: 165,
    createdAt: "2024-12-01",
  },
  {
    id: "sch-002",
    name: "Arts & Humanities Grant",
    category: "Arts",
    amount: "$3,500",
    status: "published" as const,
    deadline: "2025-05-15",
    applicants: 78,
    createdAt: "2024-12-05",
  },
  {
    id: "sch-003",
    name: "Women in STEM Scholarship",
    category: "STEM",
    amount: "$10,000",
    status: "published" as const,
    deadline: "2025-06-01",
    applicants: 203,
    createdAt: "2024-11-15",
  },
  {
    id: "sch-004",
    name: "First Generation College Award",
    category: "First Generation",
    amount: "$5,000",
    status: "published" as const,
    deadline: "2025-05-30",
    applicants: 142,
    createdAt: "2024-11-20",
  },
  {
    id: "sch-005",
    name: "Community Service Excellence",
    category: "Community Service",
    amount: "$2,500",
    status: "published" as const,
    deadline: "2025-04-15",
    applicants: 93,
    createdAt: "2024-12-10",
  },
  {
    id: "sch-006",
    name: "Environmental Studies Grant",
    category: "Environment",
    amount: "$4,000",
    status: "published" as const,
    deadline: "2025-06-15",
    applicants: 56,
    createdAt: "2024-12-12",
  },
  {
    id: "sch-007",
    name: "International Student Award",
    category: "International",
    amount: "$7,500",
    status: "archived" as const,
    deadline: "2025-03-15",
    applicants: 203,
    createdAt: "2024-11-10",
  },
  {
    id: "sch-008",
    name: "Healthcare Professionals Fund",
    category: "Healthcare",
    amount: "$6,000",
    status: "published" as const,
    deadline: "2025-07-01",
    applicants: 89,
    createdAt: "2024-12-18",
  },
  {
    id: "sch-009",
    name: "Creative Writing Award",
    category: "Arts",
    amount: "$2,000",
    status: "published" as const,
    deadline: "2025-06-30",
    applicants: 124,
    createdAt: "2025-01-05",
  },
  {
    id: "sch-010",
    name: "Entrepreneurship Fellowship",
    category: "Entrepreneurship",
    amount: "$12,000",
    status: "published" as const,
    deadline: "2025-04-01",
    applicants: 112,
    createdAt: "2024-11-30",
  },
  {
    id: "sch-011",
    name: "Minority Student Empowerment",
    category: "Diversity",
    amount: "$5,500",
    status: "published" as const,
    deadline: "2025-05-15",
    applicants: 187,
    createdAt: "2024-12-08",
  },
  {
    id: "sch-012",
    name: "Athletic Excellence Award",
    category: "Sports",
    amount: "$3,800",
    status: "published" as const,
    deadline: "2025-06-15",
    applicants: 68,
    createdAt: "2025-01-10",
  },
  {
    id: "sch-013",
    name: "Technical Innovation Award",
    category: "STEM",
    amount: "$5,000",
    status: "draft" as const,
    deadline: "2025-07-15",
    applicants: 0,
    createdAt: "2025-01-25",
  },
  {
    id: "sch-014",
    name: "Education Policy Research Grant",
    category: "Education",
    amount: "$7,000",
    status: "draft" as const,
    deadline: "2025-08-01",
    applicants: 0,
    createdAt: "2025-02-02",
  },
];

export default function AdminScholarships() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  
  // Filter scholarships based on search term and filters
  const filteredScholarships = allScholarships.filter(scholarship => {
    const matchesSearch = scholarship.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            scholarship.category.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === "" || scholarship.category === categoryFilter;
    const matchesStatus = statusFilter === "" || scholarship.status === statusFilter;
    
    return matchesSearch && matchesCategory && matchesStatus;
  });
  
  // Handler functions for scholarship actions
  const handleEditScholarship = (id: string) => {
    navigate(`/ScholarshipForm?id=${id}`);
  };
  
  const handleDeleteScholarship = (id: string) => {
    // In a real app, this would show a confirmation dialog and make an API call
    alert(`Deleting scholarship ${id}. This would be a confirmation dialog in the real app.`);
  };
  
  const handlePublishScholarship = (id: string) => {
    // In a real app, this would make an API call
    alert(`Publishing scholarship ${id}. This would update the status in the real app.`);
  };
  
  const handleArchiveScholarship = (id: string) => {
    // In a real app, this would make an API call
    alert(`Archiving scholarship ${id}. This would update the status in the real app.`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      <AdminHeader activeTab="scholarships" />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Manage Scholarships</h1>
            <p className="text-gray-600 mt-1">Create, edit, and manage all scholarship opportunities</p>
          </div>
          <Button onClick={() => navigate("/ScholarshipForm")}>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            Create Scholarship
          </Button>
        </div>
        
        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Filter scholarships by various criteria</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Input
                label="Search"
                placeholder="Search by name or category"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              
              <Select
                label="Category"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                options={[
                  { value: "", label: "All Categories" },
                  { value: "Leadership", label: "Leadership" },
                  { value: "STEM", label: "STEM" },
                  { value: "Arts", label: "Arts" },
                  { value: "Community Service", label: "Community Service" },
                  { value: "Sports", label: "Sports" },
                  { value: "Diversity", label: "Diversity" },
                  { value: "First Generation", label: "First Generation" },
                  { value: "International", label: "International" },
                  { value: "Healthcare", label: "Healthcare" },
                  { value: "Education", label: "Education" },
                  { value: "Environment", label: "Environment" },
                  { value: "Entrepreneurship", label: "Entrepreneurship" },
                ]}
              />
              
              <Select
                label="Status"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                options={[
                  { value: "", label: "All Statuses" },
                  { value: "draft", label: "Draft" },
                  { value: "published", label: "Published" },
                  { value: "archived", label: "Archived" },
                ]}
              />
            </div>
          </CardContent>
        </Card>
        
        {/* Scholarships Table */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Scholarships</CardTitle>
              <p className="text-sm text-gray-500">{filteredScholarships.length} scholarships found</p>
            </div>
          </CardHeader>
          <CardContent>
            <ScholarshipTable 
              scholarships={filteredScholarships}
              onEdit={handleEditScholarship}
              onDelete={handleDeleteScholarship}
              onPublish={handlePublishScholarship}
              onArchive={handleArchiveScholarship}
            />
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
