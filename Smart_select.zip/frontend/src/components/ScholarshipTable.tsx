import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Badge } from "./Badge";
import { Button } from "./Button";

type ScholarshipStatus = "draft" | "published" | "archived";

interface Scholarship {
  id: string;
  name: string;
  category: string;
  amount: string;
  status: ScholarshipStatus;
  deadline: string;
  applicants: number;
  createdAt: string;
}

type Props = {
  scholarships: Scholarship[];
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
  onPublish: (id: string) => void;
  onArchive: (id: string) => void;
};

// Helper function to format dates
const formatDate = (dateString: string) => {
  const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'short', day: 'numeric' };
  return new Date(dateString).toLocaleDateString(undefined, options);
};

export function ScholarshipTable({ scholarships, onEdit, onDelete, onPublish, onArchive }: Props) {
  const navigate = useNavigate();
  
  // Get status badge based on status
  const getStatusBadge = (status: ScholarshipStatus) => {
    switch (status) {
      case "draft":
        return <Badge variant="secondary">Draft</Badge>;
      case "published":
        return <Badge variant="success">Published</Badge>;
      case "archived":
        return <Badge variant="outline">Archived</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <div className="overflow-x-auto rounded-md border">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b bg-gray-50">
            <th className="py-3 px-4 text-left font-medium text-gray-500">Name</th>
            <th className="py-3 px-4 text-left font-medium text-gray-500">Category</th>
            <th className="py-3 px-4 text-left font-medium text-gray-500">Amount</th>
            <th className="py-3 px-4 text-left font-medium text-gray-500">Status</th>
            <th className="py-3 px-4 text-left font-medium text-gray-500">Deadline</th>
            <th className="py-3 px-4 text-left font-medium text-gray-500">Applicants</th>
            <th className="py-3 px-4 text-right font-medium text-gray-500">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {scholarships.map((scholarship) => (
            <tr key={scholarship.id} className="hover:bg-gray-50">
              <td className="py-3 px-4">
                <div className="font-medium text-gray-900">{scholarship.name}</div>
                <div className="text-gray-500 text-xs">Created {formatDate(scholarship.createdAt)}</div>
              </td>
              <td className="py-3 px-4 text-gray-500">{scholarship.category}</td>
              <td className="py-3 px-4 text-gray-500">{scholarship.amount}</td>
              <td className="py-3 px-4">{getStatusBadge(scholarship.status)}</td>
              <td className="py-3 px-4 text-gray-500">{formatDate(scholarship.deadline)}</td>
              <td className="py-3 px-4 text-gray-500">{scholarship.applicants}</td>
              <td className="py-3 px-4 text-right">
                <div className="flex items-center justify-end space-x-2">
                  <Button size="sm" variant="outline" onClick={() => onEdit(scholarship.id)}>Edit</Button>
                  
                  {scholarship.status === "draft" && (
                    <Button size="sm" variant="default" onClick={() => onPublish(scholarship.id)}>Publish</Button>
                  )}
                  
                  {scholarship.status === "published" && (
                    <Button size="sm" variant="secondary" onClick={() => onArchive(scholarship.id)}>Archive</Button>
                  )}
                  
                  {scholarship.status === "archived" && (
                    <Button size="sm" variant="default" onClick={() => onPublish(scholarship.id)}>Republish</Button>
                  )}
                  
                  <Button size="sm" variant="destructive" onClick={() => onDelete(scholarship.id)}>Delete</Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
