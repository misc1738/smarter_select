import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "./Button";

type Props = {
  activeTab?: string;
};

export function AdminHeader({ activeTab = "dashboard" }: Props) {
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const tabs = [
    { id: "dashboard", label: "Dashboard", path: "/AdminDashboard" },
    { id: "scholarships", label: "Scholarships", path: "/AdminScholarships" },
    { id: "applications", label: "Applications", path: "/AdminApplications" },
    { id: "users", label: "Users", path: "/AdminUsers" },
    { id: "reports", label: "Reports", path: "/AdminReports" },
  ];

  return (
    <header className="bg-white border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2" onClick={() => navigate("/")} style={{ cursor: "pointer" }}>
            <span className="text-xl font-bold text-primary">Smarter Select</span>
            <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">Admin</span>
          </div>
          
          {/* Mobile menu button */}
          <button 
            type="button"
            className="md:hidden p-2 rounded-md text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
        
        {/* Desktop navigation */}
        <nav className="hidden md:flex mt-4 border-b">
          <div className="flex space-x-8">
            {tabs.map((tab) => (
              <a
                key={tab.id}
                href={tab.path}
                className={`py-2 px-1 inline-flex items-center text-sm font-medium border-b-2 ${
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
              </a>
            ))}
          </div>
          <div className="ml-auto flex items-center">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate("/")}
              className="mr-2"
            >
              Exit Admin
            </Button>
            <div className="relative">
              <button className="flex items-center text-sm">
                <span className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                  <span className="text-xs font-medium">AW</span>
                </span>
              </button>
            </div>
          </div>
        </nav>
        
        {/* Mobile navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-2 space-y-3">
            {tabs.map((tab) => (
              <a
                key={tab.id}
                href={tab.path}
                className={`block py-2 text-base font-medium ${
                  activeTab === tab.id
                    ? "text-primary"
                    : "text-gray-500 hover:text-gray-700"
                }`}
              >
                {tab.label}
              </a>
            ))}
            <Button 
              variant="outline" 
              className="w-full mt-4"
              onClick={() => navigate("/")}
            >
              Exit Admin
            </Button>
          </nav>
        )}
      </div>
    </header>
  );
}
