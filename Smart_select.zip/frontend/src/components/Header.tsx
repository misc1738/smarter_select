import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "./Button";

type Props = {
  isLoggedIn?: boolean;
  isAdmin?: boolean;
};

export function Header({ isLoggedIn = false, isAdmin = false }: Props) {
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2" onClick={() => navigate("/")} style={{ cursor: "pointer" }}>
            <span className="text-xl font-bold text-primary">Smarter Select</span>
          </div>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <a href="/" className="text-sm font-medium hover:text-primary">Home</a>
            <a href="/Scholarships" className="text-sm font-medium hover:text-primary">Scholarships</a>
            <a href="/Resources" className="text-sm font-medium hover:text-primary">Resources</a>
            <a href="/About" className="text-sm font-medium hover:text-primary">About</a>
            {isAdmin ? (
              <Button onClick={() => navigate("/AdminDashboard")} className="bg-blue-700">
                Admin Dashboard
              </Button>
            ) : isLoggedIn ? (
              <Button onClick={() => navigate("/StudentDashboard")}>Dashboard</Button>
            ) : (
              <div className="space-x-2">
                <Button variant="outline" onClick={() => navigate("/Login")}>Login</Button>
                <Button onClick={() => navigate("/Signup")}>Sign Up</Button>
              </div>
            )}
          </nav>
          
          {/* Mobile menu button */}
          <button 
            type="button"
            className="md:hidden p-2 rounded-md text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              {mobileMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
        
        {/* Mobile navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-2 space-y-3">
            <a href="/" className="block py-2 text-base font-medium hover:text-primary">Home</a>
            <a href="/Scholarships" className="block py-2 text-base font-medium hover:text-primary">Scholarships</a>
            <a href="/Resources" className="block py-2 text-base font-medium hover:text-primary">Resources</a>
            <a href="/About" className="block py-2 text-base font-medium hover:text-primary">About</a>
            {isAdmin ? (
              <Button className="w-full bg-blue-700" onClick={() => navigate("/AdminDashboard")}>
                Admin Dashboard
              </Button>
            ) : isLoggedIn ? (
              <Button className="w-full" onClick={() => navigate("/StudentDashboard")}>Dashboard</Button>
            ) : (
              <div className="space-y-2">
                <Button variant="outline" className="w-full" onClick={() => navigate("/Login")}>Login</Button>
                <Button className="w-full" onClick={() => navigate("/Signup")}>Sign Up</Button>
              </div>
            )}
          </nav>
        )}
      </div>
    </header>
  );
}
